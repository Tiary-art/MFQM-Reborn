# MFQM 1.1.1 原版机制还原研究 — 第一阶段证据报告

**研究对象**：`[更多流沙] MoreFunQuicksandMod-1.1.1-1.7.10.jar`；Task 001 原版反编译/字节码证据；`MFQM-main (5).zip`（1.20.1 B2 实现）。  
**目标**：明确原版机制及当前移植偏差，而不是再设计一套相似玩法。  
**研究性质**：第一阶段静态证据交叉核查。Task 001 的反编译文本及字节码已包含在 B2 仓库中；本报告核对了这些文件及 B2 当前实现，但**尚未在 1.7.10 客户端测量逐 tick 轨迹，也未对全部 161 类逐方法独立反编译**。证据级别见下文。

## 1. 核心结论

1. **B2 下沉深度函数方向与用户观察的原版深陷体验不匹配**。B2 `physics/MotionMath.java` 的 `velocity()` 返回 `-min(terminal, base + depthGain * min(1,depth/2) + movingExtra + struggleExtra)`；随着深度增加，目标向下速度绝对值非减。原版 Quicksand/SoftQuicksand/Mud 的行为是多分支、以相对方块表面的 `k`、`km`、动作、随机数、阻碍等级等共同计算；不能用一条线性加速曲线替代。**不能仅据此断言原版净下沉速度严格单调减小**，必须用原版游戏测量。
2. **原版“越来越动不了”有明确的 Stuck 机制**。Quicksand 的阻碍等级 `mr` 可达145；SoftQuicksand 可达175；旧 `CustomPotionEvent` 通过移动属性修饰器和 `jumpMovementFactor` 的非线性衰减实施限制，深陷时还有横向速度清零、向方块中心牵引等。仅调整垂直速度上限不足以复原。
3. **污渍具有类型、等级、持续时间，不是碰到就全身覆盖的布尔值**。旧版 `CustomVarPlayer` 用 DataWatcher 打包 `type/level/time`；各材料接触分支决定污染类型与强度；旧 `MuddyEvent` 在湿润时降低污渍时间，并按条件逐步降低等级。
4. **原版污渍分级有可提取的深度阈值**。Task 001 的 `02_physics_and_player_state.md` 从原版方法整理出眼部相对高度阈值与等级 1–10 的对应关系（见第3节）；应恢复分段遮罩/UV 映射，而非整身透明叠层。
5. **旧版氧气 HUD 与原生 air 值存在关联**。`CustomRenderOverlayEvent.renderAirGUI` 在 AIR 绘制事件中比较旧自定义氧气与原生 air，且有专用重绘分支。新版复用原生气泡栏是用户指定的现代兼容方案，须区分“旧版事实”和“新版产品目标”。
6. **镜头遮挡必须区分实体眼睛与第三人称摄像机**。用户实测显示 B2 只要相机进入流沙就遮挡，这是新版实现缺陷；旧版摄像机碰撞与遮挡精确路径仍需逐方法追踪，不能凭主观推断直接宣称旧版一定使用某个 API。
7. **原始纹理指 MFQM 模组资源**，不是 Minecraft 原版方块纹理。应使用私有原版 JAR/纹理目录制作本地资源包与映射，公开仓库只保存映射及导入工具，避免擅自重新分发原始资源。

## 2. 原版陷落物理：可证实的结构

| 原版机制 | 原版证据 | 对移植的要求 |
|---|---|---|
| 普通流沙初始速度耗散 | `BlockQuicksand.func_149670_a`: X/Z 置0；Y > -0.1 时置0，否则 Y /= 2 | 区分入沙耗散与稳定浸没，不要只设统一目标速度 |
| 普通流沙深陷阻碍 | `mr=min(5+floor(max(0,100*(1.5-km))),145)` | 恢复随浸没深度变化的阻碍级别和实际移动属性影响 |
| 松软流沙初始耗散 | `BlockSoftQuicksand.func_149670_a`: X/Z *= 0.71；快速下落 Y /= 2 | 不得直接复用普通流沙同一套速度处理 |
| 松软流沙深陷限制 | `mr` 上限175；深处分支横向速度清零并向方块中心牵引 | 深陷几乎无法移动的表现需要独立实现 |
| 泥浆差异 | `BlockMud`：无靴且着地 X/Z *=0.1，后续再乘0.71；快速下落 Y /=10；受池形/metadata/靴子影响 | 泥浆不是换皮普通流沙 |
| 阻碍实现 | `CustomPotionEvent.onLivingUpdateEvent` 每 tick 更新指定 UUID 的移动速度 modifier（operation 2）并调低 jumpMovementFactor；高等级速度下限0.02、跳跃因子可为0 | 复原阻碍的数值与更新顺序，同时在 1.20.1 定向处理 FOV，不影响其他效果 |
| 挣扎与吸力 | `MFQM.antiHoldJumpScript`、`suctionWorldCheck` 涉及跳跃键、装备、时钟与随机数 | 不能把“挣扎”简化成每刻固定额外下降速度 |

**关键解释**：旧代码的 `k = entityY - blockY - 1`（玩家 Quicksand/Mud 分支），SoftQuicksand 再减0.2；`km=max(k,0)`。`k` 越小通常代表更深，但它不是现代通用浸没比例。原版多个分支对 `motionY` 添加抵消重力的正量（如约0.075），这些是浮力补偿，**不是“每 tick 上浮0.075格”**。净下降还受原版 Minecraft 重力、web、碰撞和 tick 顺序影响。

### 必须优先完成的原版测量

在旧版 1.7.10 相同环境中分别记录普通流沙、松软流沙、泥浆：静止下沉、水平移动、连续跳跃、从高处入沙、深层脱困。每 tick 记录脚部Y、眼高、速度Y、水平位移、阻碍等级、onGround、fallDistance、材质、池深及随机种子（可用时）。输出每 0.25 格深度区间的**净下沉速度分布**，而不是只取一个全局终端速度。完成后再决定现代版的数学近似容差。

## 3. 污渍机制：等级、类型、洗净

### 3.1 原版状态结构

`CustomVarPlayer` 以一个整数存放 `type`（低8位）、`level`（中8位）、`time`（高位）。旧 `MuddyEvent` 的 `onLivingUpdateEvent` 在湿润 `isWet` 且不处于两种特殊 LiquidMire 时，每 tick 扣除 `5 + time/100` 的污渍时间；每16 tick 且等级大于5时等级减1。干燥时另有更慢的等级/时间衰减。**这说明原版存在逐渐清洗和自然残留，而不是简单的进入水立即清零。**

### 3.2 旧接触等级阈值（Task 001 静态反编译）

| 眼部相对方块高度（原版计算坐标） | 污渍等级 |
|---|---:|
| <0.70 | 10 |
| <1.04 | 9 |
| <1.10 | 8 |
| <1.21 | 7 |
| <1.32 | 6 |
| <1.53 | 5 |
| <1.67 | 4 |
| <1.98 | 3 |
| <2.14 | 2 |
| <2.40 | 1 |
| 其余 | 0 |

这些阈值源自旧版 `getMuddyLevel` 相关反编译分析；**并非现代 1.20.1 可直接照抄的玩家眼高阈值**。需核对旧版皮肤/盔甲层的分区 UV、玩家姿态和不同材质的污染触发条件。等级越高对应的遮罩覆盖部位、覆盖顺序应从旧渲染类中提取，而不是仅根据表格臆造 UV。

### 3.3 尚待逐类核对

- 哪些方块调用污染更新，哪些为干沙或无污渍；记录 `block class → muddy type → level/time/opacity`。
- `CustomRenderPlayer` / `CustomRenderOverlayEvent` / 盔甲相关渲染类的遮罩贴图、部位、alpha、叠加顺序。
- 水、雨、特殊液体和死亡/重生的污渍变化；旧代码可能存在打包符号位边界异常，不应机械复制 bug。

## 4. 视野、材质、音效

- **第一人称遮挡**：用户要求进入对应流沙时完全不可见。应从原版相机/眼睛检测、材质采样和 overlay 渲染路径验证其触发条件；在现代版中，遮挡强度应以原版实测为准，不能继续使用 B2 的半透明占位方案。
- **第三人称**：当只有相机进入流沙而玩家未进入时，不应触发玩家窒息式 overlay；同时要检查摄像机与流沙形状的碰撞裁剪，避免穿进方块。两者是独立问题。
- **原始纹理**：本地以 `MFQM_Original_Texture_Catalog.zip` 与原版 JAR 的资源名为基准，逐一映射 block/item/entity/armor/overlay/动画帧。不要使用原版 Minecraft 沙子/泥浆纹理冒充 MFQM 原图。
- **原始音效**：需要核对原 JAR 内实际音频资产、事件触发和播放间隔。不能用 Vanilla 声音替代后宣称还原；本阶段未完成全部音频事件逐方法映射。

## 5. 当前 B2 实现偏差（源码可直接验证）

- `physics/MotionMath.java`：文件注释明言 `Candidate policy, not a measured reproduction of 1.7.10`；当前速度函数随 `depth` 增加而提高向下目标速度绝对值，且移动、挣扎均增加向下速度。
- `docs/task-0035-b2/LEGACY_PHYSICS_TRACEABILITY.md`：明确承认速度基础值、深度增益、移动/挣扎增益为现代保守提案；旧 1.7.10 逐 tick 轨迹缺失。
- 同一追溯文件明确承认：污渍旧分区 UV、自定义盔甲、清洗速率、环境气泡未完整复刻；49方块/13流体注册不等于行为还原。
- 本报告不把用户实测之外的游戏内效果写成已验证，也不把 B2 的注册数量当作完整机制数量。

## 6. 下一阶段必须交付的原版机制证据库

1. **类与方法总索引**：原版全部 161 类、继承关系、每个方法的作用、调用者/被调用者、对应新版实现；状态标记为 VERIFIED / PARTIAL / UNKNOWN / NOT_PORTED。
2. **逐材料行为矩阵**：每个原版方块的陷落公式、深度段、碰撞/射线/重力/流动、污渍、气泡、音效、氧气、伤害、掉落、特殊实体、世界生成。
3. **原版运动分支表**：每条条件写出类名、方法、字节码偏移、常量、条件、分支后速度/属性变化；注明随机和 tick 先后顺序。
4. **污渍资源图谱**：材料类型、等级、遮罩纹理/UV、身体部位、持续时间、洗净条件和测试案例。
5. **客户端视觉图谱**：第一/第三人称 camera clipping、眼部遮挡、FOV、原生 air HUD、泥浆粒子、音效触发。
6. **原版实机轨迹**：为每种关键材料保存相同场景的逐 tick 数据与录像/截图；如无法运行旧版，明确标记为缺失，不能伪称已验证。
7. **移植差异清单**：原版事实、现代适配决策、已实现位置、缺口、自动测试和真人验收各自状态。

## 7. 执行原则

**先证据、再公式、后代码。** 禁止用“看起来差不多”的通用材料 profile 覆盖原版差异。先完成 Quicksand/SoftQuicksand/Mud 三类的深度阻力与污渍分区研究，再扩展到其他方块。保留 B1 已实测通过的高速入沙衰减、Y轴稳定与异常着地修复作为回归基线，避免恢复旧机制时引入现代版回归。

## 8. 可核查的仓库证据路径

- `research/task-001/reports/02_physics_and_player_state.md`
- `research/task-001/evidence/BlockQuicksand.analysis.txt`
- `research/task-001/evidence/BlockSoftQuicksand.analysis.txt`
- `research/task-001/evidence/BlockMud.analysis.txt`
- `research/task-001/evidence/MuddyEvent.analysis.txt`
- `research/task-001/evidence/CustomVarPlayer.analysis.txt`
- `research/task-001/evidence/CustomRenderOverlayEvent.analysis.txt`
- `research/task-001/evidence/MoreFunQuicksandMod__main__blocks__BlockQuicksand.bytecode.txt`（以及 SoftQuicksand/Mud 同类文件）
- `forge-1.20.1/src/main/java/art/tiary/mfqm/physics/MotionMath.java`
- `forge-1.20.1/docs/task-0035-b2/LEGACY_PHYSICS_TRACEABILITY.md`
- `forge-1.20.1/docs/task-0035-b2/KNOWN_GAPS.md`

**结论状态**：完成第一阶段证据核对与优先级定义；**未完成**原版全类逐方法语义还原、旧版实机净速度曲线及污渍分区 UV 的精确提取。上述未完成项是下一阶段的研究任务，不应被当成已证实的还原成果。
