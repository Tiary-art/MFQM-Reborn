from pathlib import Path
import json,csv,re
import argparse
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);args=p.parse_args();r=args.root;a=json.loads((r/'indexes/methods-with-instructions.json').read_text())
def method(c,n):return next(m for m in a if m['class'].split('.')[-1]==c and m['name']==n)
rows=[]
def add(c,n,span,condition,effect,constants,source,limit='static decision; net per-tick movement NOT_VERIFIED'):
 m=method(c,n);lo,hi=map(int,span.split('-'));assert any(lo<=i['offset']<=hi for i in m['instructions']),(c,span)
 rows.append({'class':m['class'],'method':n,'descriptor':m['descriptor'],'bytecode_offset_region_inclusive':span,'condition_or_stage':condition,'effect':effect,'constants':constants,'task001_source_lines':source,'status':'VERIFIED_STATIC_MAJOR_BRANCH','limit':limit})
C='func_149670_a'
add('BlockQuicksand',C,'0-184','coordinate setup; player vs other','k=Y-blockY-1 for player; other +.5; km=max(k,0); previous k separately','.5; 1','90–118')
add('BlockQuicksand',C,'246-568','living actor; calculate mr and action flags','mr=min(5+floor(max(0,100*(1.5-km))),145); moving includes displacement/rotation','145; .0015; deltaY>.2; vy<-.1; div=1+distance/2','130–160')
add('BlockQuicksand',C,'568-615','entry/each collision callback','X/Z=0; Y>-.1 ->0; otherwise /2','-.1; 2','161–163')
add('BlockQuicksand',C,'615-1097','FX stage precedes later physics RNG','clock/action gates invoke original swim/slime/water/silverfish sounds and bubbles','128; 8;16; nextInt branches','164–201')
add('BlockQuicksand',C,'1098-1395','special EntitySandBlob / compatible unaffected actors','buoyancy .08/.1; onGround/fall reset; early return','.08;.1;1.35','202–248')
add('BlockQuicksand',C,'1396-1579','topology and jump suction','top+1 & top+2 same -> k=.001 WITHOUT recomputing km; suction conditional decrement','.001; -.05*(min(.75,km)+1)','249–260')
add('BlockQuicksand',C,'1580-1755','k>=1.2 and !splash','positive Y compensation with motion/depth denominators; web/ground randomness','.075/.07485;time%4;km/1.25','261–276')
add('BlockQuicksand',C,'1756-1875','k<1.2 and rising deltaY>.001, RNG and suction check','additional downward increment; original suction sound','-.035*10*(min(.75,km)+1)','278–281')
add('BlockQuicksand',C,'1876-2060','.9<=k<1.2','positive compensation; setStuck(mr); clear fall; random web/ground','.075/.0748;time%2','282–296')
add('BlockQuicksand',C,'2061-2171','k<.9','tick-varying a2; conditional side-specific stuck; fall reset','1.01/1.05; isTrulySink','298–308')
add('BlockQuicksand',C,'2172-2325','.5<=k<.9','web branch chooses .0725/.075; moving divides support by div+.075','.5; .0725; .075','309–315')
add('BlockQuicksand',C,'2326-2418','k<.5; k<.45 and isTrulySink','web; a2=1.05; moving denominator div+.025; force mr145','.025;.45;145','316–323')
add('BlockQuicksand',C,'2419-2514','water tail / blocked topology / common tail','positive Y /4 in water; blocked topology web/stuck; antiHoldJumpScript; nonliving web below1.45','4; .5;1.45','326–337')
add('BlockSoftQuicksand',C,'0-219','coordinate setup and living/player entry','k is QS coordinate minus .2; check drowning/muddy','.2','104–139')
add('BlockSoftQuicksand',C,'220-542','action/mr calculation','mr=min(5+floor(max(0,pow(12.5*(1.5-km),1.75))),175); div=1+2*distance +rotation','175;.001;1.75;rotation mr*.002','140–170')
add('BlockSoftQuicksand',C,'542-603','entry damping','X/Z *=.71; Y>-.1 ->0 else /2','.71;-.1;2','171–173')
add('BlockSoftQuicksand',C,'603-1218','FX and actor special cases','FX precedes general physics; EntitySandBlob special early return; later SpawnMudTentacles','clock4/128/8; random branches','174–220')
add('BlockSoftQuicksand',C,'1219-1438','topology / jump suction','two blocks above -> k=.001, km not refreshed; conditional jump penalty','-.05; .75','221–233')
add('BlockSoftQuicksand',C,'1439-1749','1.2<=k<1.3 and !splash; k>=1.3 skips subbranch','add .0735 support first; X/Z *=clamp((k-1.25)*4); subsequent .0725 assignment not used to re-add current support','1.2;1.3;.0735;17.5;1.475','234–256')
add('BlockSoftQuicksand',C,'1750-1906','k<1.2 rising displacement + RNG + suction','additional negative increment','-.035*10*(min(.75,km)+1)','258–262')
add('BlockSoftQuicksand',C,'1907-2171','.9<=k<1.2','stuck mr; player tick selects .0735/.0715+web; nonplayer position backstep; support denominator 2*div-1','.9;.0735;.0715;(k+.1)^5','263–283')
add('BlockSoftQuicksand',C,'2172-2388','k<.9; .075<=radius<.5','X/Z zero, center attraction /max(10,km*50); sufficiently strong centering changes entMoving/div','.075;.5;10;50;.005','284–301')
add('BlockSoftQuicksand',C,'2389-2507','k<.9 continued','a2 tick1.01/1.05; random ground; side-specific stuck; fall reset','1.01;1.05','302–310')
add('BlockSoftQuicksand',C,'2508-2677','.5<=k<.9','web/random support, moving denominator 4*div+.075','.0725;.075;4;.075','311–317')
add('BlockSoftQuicksand',C,'2678-2773','k<.5, and <.45 side eligible','web; moving denominator16*div+.025; force Stuck175','16;.025;175','318–324')
add('BlockSoftQuicksand',C,'2774-2882','water/topology/antiHold tail; nonliving','water positive Y /4; topology web and capped stuck; antiHold; nonliving tentacle handler','4;.5;1.45','327–342')
add('BlockMud',C,'0-582','metadata/pool safety/actor filtering/boots','mtd=max(meta,geometricDepth) when meta<3; safe boundary may reset0; WadingBoots; muddy update','meta3; depth0–3','199–283')
add('BlockMud',C,'582-914','action/mr calculation','mr=min(5+floor(max(0,pow(4*(1.5-km),1.5))),145); div=1+5*distance; rotation term','mtdkof2; .001; mr*.005','284–316')
add('BlockMud',C,'914-1023','no WadingBoots and onGround; then mtd0 path','X/Z *=.1; mtd0 returns before general /.10Y damping; nonplayer shallow support','.1;1.25;.08+.005 cap','317–329')
add('BlockMud',C,'1024-1814','special actor / FX branches','early-return actor exceptions; sounds and bubbles; affects RNG before physics','128;8; mtd>2 time32 nextInt20','330–413')
add('BlockMud',C,'1815-1884','mtd>0 normal path','X/Z *=.71; bootsFloat=false if k<1.3; Y>-.1->0 else /10','.71;1.3;-.1;10','414–419')
add('BlockMud',C,'1885-2267','dimension effects, tentacles, topology and jump suction','compat toxicity; top+2 same -> k=.001; conditional negative increment','-.05*2*(min(.75,km)+1)','420–443')
add('BlockMud',C,'2268-2596','k>=1.3, !splash','a1 .075/.07485 period8; boots .085/.1 else support denominator includes /3 and mtdkof*17.5; web or nonplayer backstep','1.3;.075;.07485;8;2;17.5','444–472')
add('BlockMud',C,'2597-2718','k<1.3 rising/RNG/suction','additional negative increment','-.035*2*(min(.75,km)+1)','474–477')
add('BlockMud',C,'2719-2999','.9<=k<1.3','stuck mr; a1 period4; mtd>2 groundfalse; support when!splash; web/positionback','.075;.07485;4','478–501')
add('BlockMud',C,'3000-3117','k<.9','a2=1/.95; setweb; side-specific stuck; no .71 repetition here','1;.95','503–514')
add('BlockMud',C,'3118-3271','.5<=k<.9','random support .0725/.075; moving divisor div+.25','.5;.25','515–521')
add('BlockMud',C,'3272-3408','k<.5','a2=1.01 for water/overwater else1.05 ifk<.475; moving divisor div+.025; force145 ifk<.45','.475;.45;145','522–533')
add('BlockMud',C,'3409-3522','inWater / blocked topology / nonliving tail','inWater positiveY=0 then -.01; antiHold only normal topology branch; blocked branch web; nonliving tentacles','-.01;.5;1.45','536–554')
# All referenced endpoints are regions, not an assertion that every nested branch has been exhaustively interpreted.
with (r/'indexes/core-motion-decisions.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
text='# 三核心主运动分支表\n\n以下'+str(len(rows))+'条为人工核对的主要阶段/深度分支，方法内十进制字节码偏移为区域（含端点），不是反编译源码行号。源码行号指附录evidence/source；完整嵌套判断仍应查逐指令文本。全部14169条跳转的结构索引在branches.csv，但不宣称均已语义还原。\n\n|类|偏移区域|条件/阶段|结果|源码行|\n|---|---|---|---|---|\n'
for row in rows:text+=f"|{row['class'].split('.')[-1]}|{row['bytecode_offset_region_inclusive']}|{row['condition_or_stage']}|{row['effect']}|{row['task001_source_lines']}|\n"
(r/'reports/02_core_motion_branches.md').write_text(text)
# Random consumers are extracted in exact bytecode order, including FX calls that can change later RNG outcomes.
randomrows=[]
for m in a:
 if m['class'].split('.')[-1] not in ['BlockQuicksand','BlockSoftQuicksand','BlockMud','MFQM']:continue
 if m['name'] not in [C,'suctionWorldCheck','antiHoldJumpScript','spawnBodyBubble','spawnBodyBubbleRandom','SpawnMudTentacles']:continue
 for idx,i in enumerate(m['instructions']):
  if 'java/util/Random.next' in i['args']:
   window=m['instructions'][max(0,idx-12):idx+5]
   randomrows.append({'class':m['class'],'method':m['name'],'descriptor':m['descriptor'],'call_offset':i['offset'],'target':i['args'],'instruction_window':' | '.join(f"{x['offset']}:{x['opcode']} {x['args']}"for x in window),'scope':'One shared World RNG may serve preceding sounds/particles; dynamic recursion/order not executed'})
with (r/'indexes/core-random-call-sites.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=randomrows[0]);w.writeheader();w.writerows(randomrows)
print('Curated major decisions',len(rows),'random consumer sites',len(randomrows))
