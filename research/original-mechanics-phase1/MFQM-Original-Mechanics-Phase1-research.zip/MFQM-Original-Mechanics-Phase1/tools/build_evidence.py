#!/usr/bin/env python3
"""Read-only JAR evidence extraction. No game execution, no redistribution of PNG/OGG/JAR.
Requires Python3/Pillow and a JDK javap. Pass source paths explicitly for reproducibility.
"""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from PIL import Image
import argparse,csv,json,re,hashlib,subprocess,collections,struct
p=argparse.ArgumentParser();p.add_argument('--jar',type=Path,required=True);p.add_argument('--task001',type=Path,required=True);p.add_argument('--b2',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--javap',required=True);p.add_argument('--fresh',type=Path)
a=p.parse_args();o=a.out
for d in ['indexes','evidence/bytecode','evidence/source','reports','tools','logs']:(o/d).mkdir(parents=True,exist_ok=True)
def save(name,data):
 (o/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def csvsave(name,rows,fields=None):
 rows=list(rows)
 with (o/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
def src(n):
 p=a.task001/'evidence'/f'{n}.analysis.txt'
 return re.sub(r'^\d+: ?', '',p.read_text(),flags=re.M)if p.exists()else''
manifest=[];png=[];masks=[];maskrows=[];comparisons=[]
with ZipFile(a.jar)as z:
 entries=[n for n in z.namelist()if not n.endswith('/')];classes=[n for n in entries if n.endswith('.class')]
 for n in entries:
  b=z.read(n);row={'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'kind':n.rsplit('.',1)[-1] if'.'in n else'other'};manifest.append(row)
  if n.endswith('.png'):
   im=Image.open(BytesIO(b));png.append({**row,'width':im.width,'height':im.height,'mode':im.mode,'animated_metadata':n+'.mcmeta'in entries})
   if '/mudOverlays/'in n:
    alpha=im.convert('RGBA').getchannel('A');values=list(alpha.get_flattened_data());bbox=alpha.getbbox()
    masks.append({'resource':n,'family':Path(n).stem[:-1],'level':int(Path(n).stem[-1])+1,'width':im.width,'height':im.height,'nonzero_alpha_pixels':sum(v>0 for v in values),'alpha_min':min(values),'alpha_max':max(values),'alpha_bbox_exclusive':str(bbox),'sha256':row['sha256']})
    # Rectangles are UV coordinate partitions, not an unverified promise about a modded player model.
    regions={'u0_16_v16_32':(0,16,16,32),'u16_40_v16_32':(16,16,40,32),'u40_56_v16_32':(40,16,56,32),'u0_32_v0_16':(0,0,32,16),'u32_64_v0_16':(32,0,64,16)}
    for region,box in regions.items():
     vals=list(alpha.crop(box).get_flattened_data());maskrows.append({'resource':n,'level':int(Path(n).stem[-1])+1,'uv_region':region,'nonzero_alpha_pixels':sum(v>0 for v in vals),'region_pixels':len(vals)})
  if n.endswith('.ogg'): pass
 sounds=json.loads(z.read('assets/morefunquicksandmod/sounds.json'))
 for fam in ['MudOverlay','SlimeOverlay']:
  for level in range(1,10):
   pre=list(Image.open(BytesIO(z.read(f'assets/morefunquicksandmod/textures/entity/mudOverlays/{fam}{level-1}.png'))).convert('RGBA').getchannel('A').get_flattened_data())
   nxt=list(Image.open(BytesIO(z.read(f'assets/morefunquicksandmod/textures/entity/mudOverlays/{fam}{level}.png'))).convert('RGBA').getchannel('A').get_flattened_data())
   comparisons.append({'family':fam,'from_level':level,'to_level':level+1,'added_nonzero':sum(x==0 and y>0 for x,y in zip(pre,nxt)),'removed_nonzero':sum(x>0 and y==0 for x,y in zip(pre,nxt)),'alpha_decreased_pixels':sum(y<x for x,y in zip(pre,nxt))})
 csvsave('indexes/archive-files.csv',manifest);csvsave('indexes/textures.csv',png);csvsave('indexes/coating-masks.csv',sorted(masks,key=lambda x:(x['family'],x['level'])));csvsave('indexes/coating-uv-coverage.csv',maskrows);csvsave('indexes/coating-level-deltas.csv',comparisons);save('indexes/legacy-sounds.json',sounds)
 # All metadata stays textual; original binary assets never leave the input JAR.
 classversions={n:struct.unpack('>HH',z.read(n)[4:8])[::-1]for n in classes}
if a.fresh:
 raw=a.fresh.read_text()
else:
 cmd=[a.javap,'-p','-c','-s','-constants','-classpath',str(a.jar)]+[n[:-6].replace('/','.')for n in classes]
 run=subprocess.run(cmd,capture_output=True,text=True);(o/'logs/javap.stderr.log').write_text(run.stderr);run.check_returncode();raw=run.stdout
(o/'evidence/fresh-javap-all.txt').write_text(raw)
# javap output is structural evidence, not a full dynamic call graph or source semantic proof.
cl=[];methods=[];calls=[];branches=[];current=None;method=None
classre=re.compile(r'^(?:(?:public|protected|private|final|abstract|static|strictfp)\s+)*(class|interface|enum)\s+([^\s<{]+)(.*)\{\s*$')
lines=raw.splitlines()
for lineno,line in enumerate(lines,1):
 m=classre.match(line)
 if m:
  kind,name,tail=m.groups();parent=re.search(r'\bextends\s+([^\s,{]+)',tail);interfaces=tail.split(' implements ',1)[-1].strip()if' implements 'in tail else''
  current={'class':name,'kind':kind,'parent':parent.group(1)if parent else('java.lang.Object'if kind=='class'else''),'interfaces':interfaces,'javap_start_line':lineno,'archive_path':name.replace('.','/')+'.class'};cl.append(current);method=None;continue
 if current is None:continue
 # Declarations have exactly two leading spaces; instructions/descriptor have >=4.
 if line.startswith('  ')and not line.startswith('   ')and line.strip().endswith(';'):
  if'('in line or line.strip()=='static {};':
   decl=line.strip();n='<clinit>'if decl=='static {};'else re.search(r'(\S+)\(',decl).group(1)
   if n==current['class']:n='<init>'
   method={'class':current['class'],'name':n,'descriptor':'','declaration':decl,'javap_line':lineno,'instructions':[]};methods.append(method)
  else:method=None
 elif method and line.strip().startswith('descriptor:'):method['descriptor']=line.split('descriptor:',1)[1].strip()
 elif method:
  inst=re.match(r'^\s+(\d+):\s+([a-z][\w]*)\b(.*)',line)
  if not inst:continue
  offset,op,args=inst.groups();record={'offset':int(offset),'opcode':op,'args':args.strip(),'javap_line':lineno};method['instructions'].append(record)
  if op.startswith('invoke'):
   target=re.search(r'// (?:InterfaceMethod|Method) (.+)',args)
   if target:
    t=target.group(1);qualified,desc=t.split(':',1);qualified=qualified.replace('"','')
    owner,callee=qualified.rsplit('.',1)if'.'in qualified else(current['class'].replace('.','/'),qualified)
    calls.append({'caller_class':current['class'],'caller_method':method['name'],'caller_descriptor':method['descriptor'],'offset':int(offset),'opcode':op,'target_class':owner.replace('/','.'),'target_method':callee,'target_descriptor':desc,'dispatch':'declared bytecode target; virtual/inherited/reflection resolution not complete','javap_line':lineno})
  if op.startswith('if')or op in ['goto','goto_w','tableswitch','lookupswitch','jsr','jsr_w']:
   branches.append({'class':current['class'],'method':method['name'],'descriptor':method['descriptor'],'offset':int(offset),'opcode':op,'target_operand':args.strip(),'javap_line':lineno,'semantic_status':'UNKNOWN (machine branch index; curated core decisions are separate)'})
assert len(cl)==len(classes)==161,(len(cl),len(classes))
archive_set=set(classes);assert {x['archive_path']for x in cl}==archive_set
catalog=json.loads((a.b2/'forge-1.20.1/src/main/resources/data/mfqm/legacy_block_catalog.json').read_text());modern={s['legacy_class']:s for s in catalog}
priority={'BlockQuicksand','BlockSoftQuicksand','BlockMud','MFQM','CustomVarPlayer','MuddyEvent','CustomPotionEvent','PotionStuck','AirEvent','CustomRenderOverlayEvent','CustomRenderPlayerEvent','MudModelRenderer','EntityRope'}
reviewed={'getMuddyLevel':'眼部相对高度分段1–10','getMuddyType':'按quicksandIDS首次匹配索引','getLastMuddyType':'残留阈值及边界错误','isTrulySink':'玩家只在client返回true','suctionWorldCheck':'先速度下限，再boots缩放，再时钟和随机','jumpKey':'仅本地玩家客户端读键','getData':'DataWatcher整数读取','getMuddyTime':'有符号整除65536','getMuddyLevel#CustomVarPlayer':'有符号整除256后掩255','getMuddyType#CustomVarPlayer':'低8位','setMuddyLevel':'高位保留+等级/类型按位组合','setMuddyType':'未mask type；-1会污染全位','setMuddyTime':'保留低16位写time','addMuddyTime':'有符号读取时间再加','checkPlayerMuddy':'开关/侧别/覆盖强度比较/类型/时间更新','func_149670_a':'实体接触完整分支；净轨迹未验证','func_149668_a':'碰撞AABB分支','getMudDepth':'池形及上覆液体','getMudSafe':'空气等非solid侧边安全规则','onLivingUpdateEvent':'事件tick状态衰减/阻碍/氧气，依类区分','RenderOverlay':'玩家眼部S采样，条件强制第一人称','renderInsideOfBlockR':'方块图标，RGB .1 / alpha1 全屏四边形','renderAirGUI':'自定义air夹原生air，QSCAir可重绘','func_78785_a':'按type/level/time选择纹理/颜色/alpha并绘制','scanChilds':'复制原ModelBox UV/位置，膨胀.2，挂为child','preRenderPlayer':'第三人称/远端模型安装','handRenderPlayer':'手部事件安装同一模型树'}
for x in cl:
 simple=x['class'].split('.')[-1];s=modern.get(simple);x.update({'class_major_minor':str(classversions[x['archive_path']]),'structure_status':'VERIFIED','semantic_status':'PARTIAL'if simple in priority else'UNKNOWN','modern_status':'PARTIAL'if s or simple in priority else('NOT_PORTED'if'.entity.'in x['class']or'.Tileentity.'in x['class']else'UNKNOWN'),'modern_location':('forge-1.20.1/src/main/java/art/tiary/mfqm/registry/ModBlocks.java; content/LegacyBlocks.java; id mfqm:'+s['id'])if s else('see reports/06_port_differences.md'if simple in priority else'未逐类建立对应；不等于断言整仓库绝无相似代码'),'source_evidence':simple+'.analysis.txt'})
for m in methods:
 simple=m['class'].split('.')[-1];key=m['name']+'#'+simple;meaning=reviewed.get(key,reviewed.get(m['name'],''))if simple in priority else''
 m['structure_status']='VERIFIED';m['semantic_status']='PARTIAL'if meaning else'UNKNOWN';m['purpose']=meaning or'方法签名/调用已提取；未逐方法人工解释，不以命名推断完成语义还原';m['modern_status']='PARTIAL'if simple in priority or simple in modern else('NOT_PORTED'if'.entity.'in m['class']or'.Tileentity.'in m['class']else'UNKNOWN')
 m['id']=m['class']+'#'+m['name']+m['descriptor']
for x in cl:
 x['method_count']=sum(m['class']==x['class']for m in methods)
 start=x['javap_start_line']-1;nextline=next((c['javap_start_line']-1 for c in cl if c['javap_start_line']>x['javap_start_line']),len(lines))
 (o/'evidence/bytecode'/(x['class'].replace('.','__')+'.txt')).write_text('\n'.join(lines[start:nextline])+'\n')
for name in sorted(priority):
 txt=src(name)
 if txt:(o/'evidence/source'/f'{name}.analysis.txt').write_text('\n'.join(f'{i}: {line}'for i,line in enumerate(txt.splitlines(),1))+'\n')
# Use caller/callee IDs to preserve overloads; JSON has every instruction for reliable lookup.
callee_counts=collections.Counter(c['target_class']+'#'+c['target_method']+c['target_descriptor']for c in calls)
caller_counts=collections.Counter(c['caller_class']+'#'+c['caller_method']+c['caller_descriptor']for c in calls)
for m in methods:m['declared_incoming_sites']=callee_counts[m['id']];m['outgoing_sites']=caller_counts[m['id']]
save('indexes/methods-with-instructions.json',methods);csvsave('indexes/classes.csv',cl)
fields=['id','class','name','descriptor','declaration','purpose','structure_status','semantic_status','modern_status','declared_incoming_sites','outgoing_sites','javap_line']
csvsave('indexes/methods.csv',({k:m[k]for k in fields}for m in methods));csvsave('indexes/calls.csv',calls);csvsave('indexes/branches.csv',branches)
# Per-block behavior facts are presence indexes. Unresolved inheritance/branch semantics are explicit.
blockrows=[];coatingrows=[];soundrows=[]
for s in catalog:
 name=s['legacy_class'];t=src(name);p=a.task001/'evidence'/f'{name}.analysis.txt'
 refs=[]
 for i,l in enumerate(t.splitlines(),1):
  if re.search(r'func_72908_a|func_72980_b',l):
   q=re.findall(r'"([^"]+)"',l)
   for sound in q:soundrows.append({'class':name,'source_line':i,'event_or_string':sound,'code':l.strip(),'condition_status':'PARTIAL; see source enclosing short-circuit/tick/random conditions','archive_ogg':'not inferred from name alone'})
  if 'getMuddyType('in l:refs.append(l.strip())
 blockrows.append({'legacy_id':s['legacy_id'],'class':name,'parent':s['parent'],'b2_id':'mfqm:'+s['id'],'semantic_status':'PARTIAL'if name in priority else'UNKNOWN','contact_override':'func_149670_a('in t,'collision_override':'func_149668_a('in t,'ray_or_shape_override':'func_149719_a('in t or'func_149731_a('in t,'random_tick_override':'func_149674_a('in t,'source_has_muddy_call':'checkPlayerMuddy('in t,'source_has_bubbles':'Bubble'in t,'source_has_sounds':'func_72908_a'in t or'func_72980_b'in t,'source_has_oxygen':'isDrowning'in t or'checkEntityUnder'in t,'source_has_drop':'func_149650_a('in t or'getDrops('in t,'special_entity_refs':'; '.join(sorted(set(re.findall(r'\bEntity[A-Z]\w*',t)) - {'EntityPlayer','EntityLivingBase','Entity','EntityMob','EntityItem','EntityPlayerMP'})),'worldgen':'UNKNOWN; registration/world-generator call graph, not block class alone','remaining':'Inherited methods, trigger paths and all branch formulas require individual review','source':p.name})
 coatingrows.append({'class':name,'legacy_id':s['legacy_id'],'declares_checkPlayerMuddy':bool(re.search(r'public void checkPlayerMuddy',t)),'contact_call_present':'this.checkPlayerMuddy('in t,'type_expression':'; '.join(refs)or'NO DIRECT CALL FOUND; inherited/other entry paths unverified','max_opacity':'hardcoded1000'if name=='BlockMud'else'constructor arrays / special body; see source','semantic_status':'PARTIAL'if name in priority else'UNKNOWN'})
csvsave('indexes/material-behaviors.csv',blockrows);csvsave('indexes/material-coating-call-index.csv',coatingrows);csvsave('indexes/material-sound-sites.csv',soundrows)
# Exact type-array order; note duplicates and aliases instead of inventing material identity.
ids=re.search(r'quicksandIDS = new Block\[\]\{([^}]+)',src('EntityRope')).group(1);ids=re.findall(r'MFQM\.(\w+)',ids)
arrays={}
for name in ['mudTypesColors','mudMaxOpacity','mudLastOpacity','mudIncOpacity']:
 rawarr=re.search(name+r' = new int\[\]\{([^}]+)',src('MFQM')).group(1);arrays[name]=[int(x.strip(),0)for x in rawarr.split(',')]
slime={0,1,3,6,7,8,15,19,20,21,25,28,31}
csvsave('indexes/coating-type-map.csv',({'type':i,'block_field':n,'color_rgb':f'#{arrays["mudTypesColors"][i]:06x}','mask_family':'SlimeOverlay'if i in slime else'MudOverlay','max_opacity_array':arrays['mudMaxOpacity'][i],'last_opacity_array':arrays['mudLastOpacity'][i],'inc_opacity_array':arrays['mudIncOpacity'][i],'warning':'Array defaults, actual updater may alias type or hardcode values (Mud -> Mire type9)'}for i,n in enumerate(ids)))
save('manifest.json',{'original_jar_name':a.jar.name,'sha256_before':hashlib.sha256(a.jar.read_bytes()).hexdigest(),'class_count':len(cl),'method_count':len(methods),'call_sites':len(calls),'branch_sites':len(branches),'file_count':len(entries),'png_count':len(png),'ogg_count':sum(n.endswith('.ogg')for n in entries),'mcmeta_count':sum(n.endswith('.mcmeta')for n in entries),'texture_catalog_zip':'not supplied/found; use JAR resources as primary inventory','b2_archive_zip':'MFQM-main (5).zip not supplied/found; compare existing B2 worktree 03a6a20354bb98174a970754293411b3a7197970 instead','runtime_1710':'NOT_RUN','all_class_semantics':'NOT_COMPLETE','extractor':'javap structural + Task001 CFR readable evidence + direct PNG metadata/alpha statistics; no original assets copied'})
print(json.dumps(json.loads((o/'manifest.json').read_text()),ensure_ascii=False))
