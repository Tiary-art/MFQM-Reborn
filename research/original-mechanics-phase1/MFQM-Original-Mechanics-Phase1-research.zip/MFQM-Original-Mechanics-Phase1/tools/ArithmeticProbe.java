/** Independent Java arithmetic probe copied from cited expressions. NOT a Minecraft trajectory or game test. */
public final class ArithmeticProbe {
  static int qs(double k){return (int)Math.min(5+Math.floor(Math.max(0,100*(1.5-Math.max(k,0)))),145);}
  static int soft(double k){return (int)Math.min(5+Math.floor(Math.max(0,Math.pow(12.5*(1.5-Math.max(k,0)),1.75))),175);}
  static int mud(double k){return (int)Math.min(5+Math.floor(Math.max(0,Math.pow(4*(1.5-Math.max(k,0)),1.5))),145);}
  static int level(double delta){double[] t={.7,1.04,1.1,1.21,1.32,1.53,1.67,1.98,2.14,2.4};for(int i=0;i<t.length;i++)if(delta<t[i])return 10-i;return 0;}
  static int setLevel(int d,int v){return (d/65536*65536)|(v*256)|(d&255);}
  static int setType(int d,int v){return (d/256*256)|v;}
  static int setTime(int d,int v){return (d&65535)|(v*65536);}
  static void check(boolean x){if(!x)throw new AssertionError();}
  public static void main(String[] args){
    int death=setTime(setType(setLevel(5000*65536+10*256+4,0),-1),0);
    check(death==65535);check((death&255)==255);check(((death/256)&255)==255);check(death/65536==0);
    check(soft(1.6)==0);check(mud(1.6)==0);check(qs(1.6)==5);
    check(level(.7)==9);check(level(2.4)==0);check(level(Math.nextDown(.7))==10);
    System.err.println("PASS: 10 arithmetic checks only; NOT original game execution. deathData="+death+"; soft/mud k>1.5 NaN cast to 0.");
    System.out.println("k,material,raw_mr_before_deep_override,horizontal_collision_corrector,speed_multiplier,initial_jump_factor,post_formula_jump_factor,scope");
    for(double k:new double[]{1.6,1.5,1.3,1.2,1,.9,.75,.5,.45,0,-.5})for(int which=0;which<3;which++)for(int c=0;c<2;c++){
      int mr=which==0?qs(k):which==1?soft(k):mud(k);double power=mr-5;
      double speed=Math.max(1/Math.pow(1+power*(1+c/2.0)/50,2),.02);
      double jump=.02/Math.max(Math.pow(1+power*(1+c*2.5)/1000,8),1);if(jump<.005)jump=0;
      // No update occurs for mr<=0; preserve external tick's starting factor in that case.
      if(mr<=0){speed=1;jump=.02;}
      System.out.printf(java.util.Locale.ROOT,"%.4f,%s,%d,%d,%.9f,0.020000000,%.9f,raw static formulas; not net motion; branch overrides and equipment excluded%n",k,new String[]{"Quicksand","SoftQuicksand","Mud"}[which],mr,c,speed,jump);
    }
  }
}
