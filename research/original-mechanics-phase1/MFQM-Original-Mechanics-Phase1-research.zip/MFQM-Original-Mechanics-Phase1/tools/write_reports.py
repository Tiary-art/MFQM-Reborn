from pathlib import Path
import csv,json,re,hashlib,collections
import argparse
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--work',type=Path,required=True);args=p.parse_args();r=args.root;d=r/'reports';w=args.work
def put(name,text):(d/name).write_text(text.strip()+'\n')
put('01_scope_and_evidence.md',r'''
# 范围、来源和证据等级

本轮任务为原始文件研究，不继续修改1.20.1的运动、贴图或玩法，不推进Task004，不更新/合并B2 PR。时间2026-11-18（北京时间）。附件自身是一份带有既有结论的研究任务书；本轮把这些结论当作待核对命题，重新查原始JAR，而非当作原作者源码。

## 输入

|输入|本轮实际使用情况|
|---|---|
|原始MFQM 1.1.1 / 1.7.10 JAR|用户此前上传件，1,644,655字节；SHA-256 `2a0809e13f2267b0eb981606164e863bc52bcdc326120b0ca27fd845a2f0db6b`，前后相同|
|Task001研究|使用B2仓库research/task-001中的文本；另对原JAR重新javap全部类，重新CFR解包；13个优先类的CFR文本与Task001逐文本一致|
|B2实现|本地分支task/0035-b2-consolidated，提交03a6a20354bb98174a970754293411b3a7197970；未假定它就是附件提到的ZIP|
|MFQM-main (5).zip|本轮未提供/未找到，不能宣称逐字节核对该ZIP；B2对比只针对上述提交|
|MFQM_Original_Texture_Catalog.zip|本轮未提供/未找到；直接清点原JAR资源，不等待素材包，也不以Minecraft原版图冒充原图|
|1.7.10官方客户端及MCP SRG|为核对旧Biped UV和相机射线链，读取官方客户端并校验官方SHA-1，配Forge Maven的MCP1.7.10 SRG；仅静态外部参考，不是启动旧游戏；URL/hash见evidence/external/provenance.json|

原JAR实际为484个条目、463个文件、161个class、247张PNG，其中162张位于textures/blocks；48份mcmeta、2份OGG。**162是方块PNG数，不是全部纹理数**。

## 已完成的证据工作与边界

- 161/161类、1955个声明方法结构索引（包括构造器/静态初始化器）、29276个invoke调用位置、14169个跳转位置。结构来自本轮javap原字节码；异常表保留在原始文本。
- 49个可证实旧Block注册对象的逐项行为存在性索引；实际算法仅优先深入三核心。`source_has_*`只表示本类源码有该调用，不等于继承后的完整行为或游戏实测。
- 三核心39条人工核对的主要运动阶段/深度分支；全部嵌套条件、兼容实体分支尚非逐条解释完成。80个相关World RNG消费调用点保留偏移/上下文，供后续精确重放。
- 20张污渍遮罩的尺寸、alpha统计、UV区覆盖与逐级像素差；33个污渍类型的颜色/默认参数/遮罩族表；13个重点类二次CFR比对。
- 10项独立Java算术检查通过，验证NaN转int及打包操作等；这不是执行原模组、不是原版GameTest，更不是净轨迹数据。

## 状态定义

`VERIFIED`只用于归档/指令/像素/算术直接支持的窄结论；`PARTIAL`为路径已读但外部依赖、全部分支或运行效果未闭合；`UNKNOWN`没有充分解释；`NOT_PORTED`用于已识别但未恢复的旧实体/TileEntity链。结构验证、语义验证、运行验证和移植状态是不同列。调用图只保存字节码声明目标，未解析所有虚调用、继承目标、反射和Forge事件调度。

不能把“161类已反汇编”写成“161类1955方法都已语义还原”。CFR输出158份Java（内部类可并入外类），CustomWorldGen的5个方法报告Unable to fully structure code；完整错误摘要保留。

本轮**未启动1.7.10 Forge客户端/专服**，没有原版逐tick曲线或录像。本轮取得的官方客户端JAR仅供静态读取，仍缺旧Forge运行/测量环境及插桩链。原版净速度单调性、RNG跨tick路径和旧事件顺序均不能据此标成已测。

文件导航：classes.csv / methods.csv / calls.csv / branches.csv / methods-with-instructions.json可机器查询；evidence/bytecode保存逐类原字节码，evidence/source为重点CFR分析文本。附录保留SRG字段，不把反编译局部变量名当原作者命名。
''')
put('03_stuck_and_tick_order.md',r'''
# 阻碍、坐标与tick顺序

## 不能把旧k当现代浸没比例

Quicksand/Mud玩家计算 `k=entity.posY-blockY-1`，非玩家为`entity.posY-blockY+.5`；Soft在此基础上减.2。`km=max(k,0)`与上一帧k独立保存。若上面连续两格同材料，只把k改成.001，**km没有重算**，所以后续分支选择与分母可以使用不同的量。

旧玩家坐标框架尤须谨慎：官方1.7.10 EntityPlayer的SRG `func_70047_e`（obf yz.g）返回.12，构造/复位中yOffset字段field_70129_M有1.62的赋值；不能把它直接当作现代玩家脚部Y+1.62。此为外部Vanilla参考，具体客户端/服务端玩家子类、姿态和Forge补丁仍需运行确认。测量时必须同时记posY、AABB.minY、eyeHeight和eyeWorldY，不能把posY列直接命名“脚部Y”。

## mr不共用一条曲线

三式均是碰撞分支的局部基础值，后面还会被深区强制值/装备规则覆盖：

- QS：`min(5+floor(max(0,100*(1.5-km))),145)`。
- Soft：`(int)min(5+floor(max(0,pow(12.5*(1.5-km),1.75))),175)`。
- Mud：`(int)min(5+floor(max(0,pow(4*(1.5-km),1.5))),145)`。mtdkof在该路径为2，不是QS的10。

Soft/Mud当km>1.5时非整数次幂底数负，Java NaN沿Math.max/floor/min传播，最终转int为0。不是先夹底数为0得到5。独立Java算术核查已验证；这不证明实际碰撞中该输入频率，也不决定新版应否复制旧边界行为。

QS/Soft/Mud在k<.45且isTrulySink时另强制145/175/145。`isTrulySink`对玩家返回world.isRemote，对非玩家返回true。原版部分阻碍只在客户端写，不能把现代服务端权威协议冒充旧事实。

## 真正移动限制由CustomPotionEvent实施

每次LivingUpdate先移除固定UUID `73A49882-85A3-4896-AD2D-8C591E24AA62`旧modifier。若Level>0，p=Level-5；水平碰撞时c=0，否则c=1：

```
jumpMovementFactor /= max((1+p*(1+c*2.5)/1000)^8,1)
speed=max(1/(1+p*(1+c/2)/50)^2,.02)
```

p>=250时jumpMovementFactor=0、speed=.02；算后jumpMovementFactor<.005置0。然后添加operation2、amount=speed-1、不保存的移动属性修饰器，Level置0；未续期下一次0→-1。PotionStuck.save/load为空。MFQM.setStuckEffect直接委托setter，并非全世界统一取最大值；多个接触回调和boots脚本的次序可能改变最终Level。

静态算术表在static-stuck-arithmetic.csv，其中jump起值.02是明确的探针输入，**不是测到的每tick起始值**；表未执行深区强制值、web或装备逻辑。它只能展示表达式的数值，不是运动模型。

## 必须保留的次序约束

三类先保存旧Y/上一Y/旧motionY，再识别动作。QS先清X/Z再Y耗散；Soft先X/Z×.71再Y耗散；Mud无靴着地先×.1，但mtd0分支会提前return，后面的×.71和Y/10并不总执行。特殊生物/兼容实体还可能提前返回。

声音/泡泡代码在多条后续物理随机判断前消费同一个World RNG。删除一段“纯特效”代码，或改成独立Entity RNG，可能改变后面的吸力/web/着地结果，不能只保持表面概率就宣称重放一致。

吸力不是固定挣扎加速：`VelY=max(prevMotionY*10,.25)`，客户端穿靴条件再缩放，然后time取模与nextInt(5)筛选。这里不是abs(prevMotionY)；负的入射速度会被.25下限替代。碰撞中的jump使用ΔY>.2，另有ΔY>.001的上升分支；按住跳键由末端antiHoldJumpScript处理，不是同一个条件。负重每32刻刷新缓存，armor/boots/heavy命名还影响阻碍与Y补偿。

典型正增量.075/.0735/.0725是修改motionY的浮力补偿，**不是每刻位移**。web、重力、碰撞、ground状态、位置回退和事件先后仍影响净运动。Soft在1.2<=k<1.3的路径先加.0735补偿，之后某分支给局部a1赋.0725；本次字节码中该赋值在已执行的dadd后，不能追溯改变那次补偿（偏移1465–1526与1627–1630）。

本轮没有测原版净下沉曲线，不认定“净速度必然严格随深度单调减小”。可以确认B2的线性深度增益无法表达这些原分支，但不能直接反向造一条递减曲线作为还原。
''')
put('04_coating_state_uv.md',r'''
# 污渍：类型、等级、时间、UV和洗净

## 状态与持久化

CustomVarPlayer将type/level/time打包一个DataWatcher整数，属性名PlayerMuddyControl，NBT名MuddyLevel。低8位type；level是`(data/256)&255`；time是有符号整除65536。setter没有完整范围约束，不能等同于安全的三字段现代结构。

MuddyEvent死亡序列setLevel(0)→setType(-1)→setTime(0)会产生data=65535，读到type255/level255/time0。独立Java算术检查通过；没有验证旧游戏视觉/重生结果。渲染有mt>50门槛，所以不能只根据异常level推断死亡后全身显污。getLastMuddyType用`>`而非`>= length`、MudModelRenderer用`<= colors.length`均有边界风险；这是未来迁移需明确修复/兼容的旧行为，不应机械照搬。

## 三核心污染更新实际不同

|材料|type来源|覆盖比较|时间上限/增加|干燥残留阈值|
|---|---|---|---|---|
|Quicksand|quicksandIDS首次匹配本块：4|preLevel×(maxOpacity/1000) > oldLevel×(oldTime/1000)|5000 / +100|type4：1000|
|SoftQuicksand|本块：17|同上|max2000 / +100|type17：1000|
|Mud|明确调用getMuddyType(MFQM.MireBlock)：9，**不是Mud自身索引29**|preLevel > oldLevel×(oldTime/1000)|硬编码1000 / +50|type9：1000|

QS/Soft参数由MFQM注册处mudMax/Last/IncOpacity数组传入；Mud的更新器硬编码，不能误用数组index29的max2000/inc100。覆盖等级使用玩家posY+eyeHeight-blockY阈值，从<.7→10、<1.04→9、<1.10→8、<1.21→7、<1.32→6、<1.53→5、<1.67→4、<1.98→3、<2.14→2、<2.4→1，其余0；边界等号落在下一档。坐标须先按旧玩家框架核对，不能原样当现代脚部Y差。

完整33类型色值/默认数组/遮罩族见coating-type-map.csv。quicksandIDS里BrownClay出现两次，getMuddyType首次返回23，不能据表给同一块同时配23/24两个运行身份。每个Block的直接checkPlayerMuddy调用见material-coating-call-index.csv；无直接调用不等于继承或外部路径一定没有污渍。

## 洗净不是统一倒计时

QSCover开关控制MuddyEvent注册和方块更新。服务端玩家type>=0、time>0时：

- 湿润isWet，且不处于两种LiquidMire的L检测中：time每次减`5+time/100`并夹0；time%16==0且旧level>5时level减1。
- 干燥：time%1024==0且level>5、time<1000才降1级；time%2==0且time>该类型lastOpacity才减1。

这里“time%16”等周期条件指worldTime，非污渍time字段。QS/Soft可以逐步降到1000后停止干燥时间衰减；Mud硬编码上限1000而type9残留1000，饱和时干燥不会继续减。time恰1000也不满足level降级的`time<1000`条件。**在这些状态条件下，干燥可以保留污渍；不是必然最终洗白。**未饱和、被其它类型覆盖、湿润和异常打包路径需分别测量。

## 遮罩选择与绘制

MudModelRenderer读取type/level/time：mt>50、level>0且类型通过检查后绘制。颜色由mudTypesColors[type]的RGB乘到纹理；alpha=`min(1,mt/1000)`，所以time1000以后alpha已饱和，5000的时间上限并不是alpha5。level选择`textures[level-1]`，不是一个整身透明量。

type {0,1,3,6,7,8,15,19,20,21,25,28,31}用SlimeOverlay；其余用MudOverlay。三核心QS4、Soft17、Mud实际9均用MudOverlay。两族各10张64×32，遮罩原图未打包进本报告。

CustomRenderPlayerEvent.scanChilds遍历`renderer.field_77109_a`的ModelRenderer/ModelBox，复制原UV起点和box几何，膨胀.2并挂child。手部RenderHandEvent也安装该树。官方旧RenderPlayer+SRG确认该字段是主模型，g/h两个独立盔甲模型不是此处遍历目标。因此目前证据支持主身体/手部模型附层，**不支持“旧代码此路径必然覆盖所有盔甲”**。盔甲遮住身体层的实际表现仍需原版实测。

旧标准Biped为64×32：腿UV[0,16)×[16,32)，躯干[16,40)×[16,32)，双臂共享/镜像[40,56)×[16,32)，头[0,32)×[0,16)，帽壳[32,64)×[0,16)。从官方客户端ModelBiped构造器和SRG字段核对，详见外部文本附录。不能把这套UV无转换套现代64×64、Alex或自定义盔甲。

下表是各区域alpha>0像素数，非三维表面积百分比；完整逐级数据见coating-uv-body-map.csv。两族级别逐对比较均未发现上一等级非透明像素被删或alpha下降，证实是逐级扩张的遮罩，而非单靠提高整身alpha。
''')
# append measured table, computed from CSV not hand-filled
u=list(csv.DictReader((r/'indexes/coating-uv-body-map.csv').open()));txt='\n|遮罩族/等级|腿|躯干|手臂|头|帽壳|\n|---|---:|---:|---:|---:|---:|\n'
for fam in ['MudOverlay','SlimeOverlay']:
 for lev in range(1,11):
  group=[x for x in u if Path(x['resource']).name==fam+str(lev-1)+'.png'];txt+=f'|{fam} / {lev}|'+ '|'.join(x['nonzero_alpha_pixels']for x in group)+'|\n'
with (d/'04_coating_state_uv.md').open('a')as f:f.write(txt+'\nMud在等级6首次出现头UV非透明像素；Slime在等级7首次出现头UV像素；等级1/2两族均仅腿区域有像素。帽壳区域20张图均无非透明像素。实际动画姿态/装备遮挡/现代左右独立UV重映射未验证。\n')
put('05_camera_air_audio_resources.md',r'''
# 相机、遮挡、FOV、氧气、气泡、音效与原图

## 眼部遮挡：已可进一步验证的原版路径

CustomRenderOverlayEvent.RenderOverlay遍历其**自己的30元素数组**（不是EntityRope的33元素同序数组），传入Minecraft.thePlayer到MFQM.isEntityInsideOfBlockS。该方法用`player.posY+eyeHeight-.2+overCor`，按方块位置/上沿判断；部分BlockFluidClassic有.15修正，Moss有上移采样。它没有传入独立摄像机坐标。

命中后取图标；该overlay数组i==19特判图标side1，此处19是Moss，不是EntityRope数组的SwallowingFlesh索引19，不能混用索引。QSThirdPerson配置名实为“Force camera to firstperson in deep”，config.get声明默认true（代码另有getBoolean(false)读取fallback）；启用时将thirdPersonView写0。随后仅视角0且renderViewEntity的func_70608_bn为false时画inside quad。应保留原SRG条件，不把它未经核对解释为任意“相机未被方块挡住”。

renderInsideOfBlockR绑定原方块atlas图标，glColor4f(.1,.1,.1,1)，在identity矩阵下画全屏quad。直接测JAR内三核心材料对应的五份默认/变体图标原图alpha均为255，故对这些原图该绘制输入是**不透明深色遮挡**，与B2的半透明.78占位不同。实际渲染事件/其它mod相互作用尚未运行核验。

## 相机裁剪与实体碰撞是两条路径

官方1.7.10 EntityRenderer.func_78467_g（blt.h）第三人称有8条±.1偏移射线，用World.func_72933_a。World该重载调用总方法(false,false,false)，因此不因“忽略无碰撞箱”而先跳过空实体AABB；Block.canCollideCheck默认允许，再调用Block.collisionRayTrace，它会更新Block bounds并求轮廓交点。QS/Soft没有重写canCollideCheck/collisionRayTrace；Soft更新bounds为顶.85/内层1。**空实体碰撞箱不代表旧相机射线也为空。**这是Vanilla原始类+mod覆盖方法的静态链，不是已测旧Forge摄像机轨迹；Forge补丁/第三方事件仍未穷尽。

现代1.20.1 Camera.getMaxZoom使用ClipContext.Block.VISUAL，BlockBehaviour.getVisualShape默认返回getCollisionShape。B2 SinkingBlock空实体碰撞且未覆盖visual shape，因此视觉射线沿用空形状；B2 SinkHud随后只看MainCamera.position，造成“玩家在外而第三人称相机进沙也遮挡”的代码路径。修正需分开研究视觉shape/相机裁剪，以及玩家眼部触发overlay，不应靠把流沙做成实心碰撞体解决。

## FOV

旧CustomPotionEvent缓存MFQM.SIFOV：不受stuck时更新缓存，stuck Level>=0时event.newfov回到缓存；拉弓另乘弓系数。它并不是数学上逐个排除MFQM UUID，所以可能连其他时变FOV也冻结。B2定向排除自身速度modifier属于现代兼容决策，不应标成旧代码直接复刻；还应分别验证正常FOV、冲刺、药水、飞行、弓/望远镜和其它mod。

## 氧气与伤害

AirEvent服务端按EntityRope数组检测：跳过6/7/13/15/21，22用M采样，其余普通采样；覆盖时自定义Watcher air大于-1则减1并return，离开最多补5到300。客户端只在自定义air更少时向下夹原生air。CustomRenderOverlayEvent在AIR事件也向下夹原生air，QSCAir开启会取消默认并自行画原版图标。

MFQM.isDrowning在对应氧气开关关闭时直接true，不表示“关闭伤害”；开启时服务端gma<0且worldTime%16==0则置0并返回true。三核心再按眼部、存活、服务端检查调用max(maxHealth*.1,2)*DmgMul的drown伤害。真实掉血频率仍受hurt resistance/其它事件影响，不能把调用次数直接算DPS。

因此“原生气泡UI”并非原版完全无关的创新，但B2的服务端native-air共享预算/水肺处理是不同实现/现代产品方案。旧代码的WaterBreathing、Respiration、与水切换整体效果本轮未测，不能据B2测试反证旧版。

## 三核心音效与泡泡

原JAR自有sounds.json只有mob.bee.hurt、mob.bee.say，两份对应OGG。三核心所读路径大量使用旧Minecraft事件名：game.player.swim、mob.slime.attack、mob.magmacube.jump、mob.silverfish.step、liquid.water；Soft还用step.sand/step.grass/dig.sand。原版使用Vanilla声音是直接事实；B2 block.mud.step等不同事件并不能据此算对应还原。须保留事件、volume/pitch表达式、时钟和随机调用次序。

|材料|原代码中主门控/例子|泡泡差异|
|---|---|---|
|QS|time%128，移动按movCof，跳跃%8，splash；swim音高rand*.25+.1；跳跃slime attack|入沙玩家nextInt2三泡，移动nextInt5一泡；另%16且nextInt10 body bubble|
|Soft|静止%4，移动movCof/2，跳跃%8；silverfish+沙/草组合|本回调无QS式BodyBubble调用，但调用SpawnMudTentacles，不能据此宣称全局无任何效果|
|Mud|mtd0提前return；更深用%128/移动/跳跃/入沙门控；pitch与QS有差异|splash nextInt3两泡、移动nextInt7一泡、跳跃nextInt5三泡；mtd>2且%32、nextInt20的环境泡还在外层门控内，不能当独立1/640每刻事件|

源码各播放点在material-sound-sites.csv；随机调用顺序在core-random-call-sites.csv。spawnBodyBubble/Random内部有实体/客户端/表面/配置等附加条件，调用出现不保证每次实际生成。此阶段未听验、未跑原版粒子帧率，不把事件存在写成实测。

## 原图与授权

QS实际注册morefunquicksandmod:quicksand；Soft metadata0→SoftQuicksand1、1→SoftQuicksand0、2→SoftQuicksand2；Mud默认mud，兼容维度还可能改取外部模组图标。这是精确资源名，不能用minecraft:sand/red_sand/mud冒充MFQM原图。core-texture-map.csv和全部247纹理清单/48动画JSON保留原始大小写和哈希。

原图并不全为16×16静态文件：有32像素宽、纵向动画条，以及20张64×32污渍遮罩。整套block/item/entity/armor/overlay映射需按用途区分。当前B2三核心只用Vanilla占位，是资源偏差；本次仅输出名称/尺寸/哈希/统计和文本证据，没有拷贝原PNG/OGG/JAR进交付包，也没有AI生成或重绘。独立纹理目录ZIP缺失不妨碍对JAR内真实文件做静态清点。
''')
put('06_port_differences.md',r'''
# 原版事实、B2差异与后续修复约束

对比基线为B2提交03a6a20，不是未经取得的MFQM-main (5).zip。下列“确认”均为本轮静态文件/表达式验证，运行状态另列。本轮没有改这些代码。

|项目|原版事实/证据|B2位置和差异|证据/运行状态|
|---|---|---|---|
|深度参数|玩家/非玩家k不同，Soft再-.2，km单独保存|ContactSampler通用depth/immersion；MotionMath随depth增大而加快目标下沉|静态确认；旧净曲线NOT_RUN|
|持续Y|多段正补偿+web+ground+随机，仍受旧引擎积分|MotionMath固定net目标，base+depth+moving+struggle|已实现现代提案，不是还原|
|入沙|QS/Soft快落/2，Mud特定路径/10；慢Y先0|MotionRuntime首步扫掠/.08穿入和3刻阻尼|现代安全适配，保留B1回归基线；不要直接删|
|横向|QS清零；Soft阻尼后深处清零+中心牵引；Mud浅层提前返回及boots差异|SinkMath通用profile/.5 immersion中心牵引门槛|部分相似，分段与坐标不等价|
|mr|QS线性k、Soft幂1.75、Mud幂1.5；深区强制值|SinkMath `round(5+(max-5)*immersion)`|明确不同，非只调max值可修复|
|实际阻碍|CustomPotionEvent碰撞corrector、8次幂jump衰减和threshold|SinkMath只给速度系数；MotionRuntime另抑跳|不能标成旧jumpMovementFactor等价|
|挣扎|ΔY判跳/上升、客户端持键、boots/负重、World RNG吸力|固定struggleExtra目标速度；意图包|现代协议可保留，效果不能当原公式|
|RNG与次序|FX与物理可消费同一World RNG；多回调/实体例外|中央预算+Entity RNG+最强Contact一次结算|现代预算/权威适配，旧精确轨迹不保真|
|污渍类型|33类型，Mud实际借Mire9；可覆盖比较|SinkState只有三核心profile residueType|丢失类型和污染更新差异|
|污渍等级|1–10分段阈值和level纹理|residueTicks整身alpha，无level|核心视觉差异|
|污渍时间|每材料max/inc/last不同，干燥可停在残留阈值|接触+5，离开-1到0，水雨-50|清洗/残留规律不等价|
|污渍纹理|两族20张64×32、type着色、mt/1000 alpha|CoatingLayer/CoatingHands使用Vanilla block纹理|占位，不是原始MFQM美术|
|盔甲|已追踪路径只装主Biped子模型；完整装备显示未测|B2主动加标准盔甲覆盖|现代新增行为，不能倒写为原版已证实|
|眼部遮挡|player eyes-.2 S检测；可强制第一人称；核心不透明RGB.1|SinkHud只按MainCamera.position，.78透明|触发对象和强度都不同|
|相机射线|旧Vanilla不跳过空实体AABB，求Block轮廓|现代VISUAL默认空collision，无专用visual shape|静态链确认；旧Forge实机未测|
|空气HUD|旧自定义Watcher向下夹原生air，QSCAir可重绘|NativeAir/SinkEngine单authority nativeSupply|现代兼容选择，须与旧事实分开|
|声音|旧核心已有Vanilla事件及精确门控/pitch|MaterialEffects换成泥步等统一fallback|素材合法不等于声音行为还原|
|泥浆几何|metadata/池宽/液体/侧边/装备|MudGeometry部分覆盖|保留已测现代功能；逐分支另核验|
|49/13数量|49是注册对象数、13原BlockFluid族|B2全量注册和现代流体框架|注册覆盖已做；原行为不能按数量宣称完成|

## 不进入编码的修复顺序

1. 先建立旧版客户端/服务端同场景轨迹和RNG/回调次序数据；模型容差待数据，不再凭体验反向制造一条统一递减曲线。
2. 运动先逐材料保留入口、坐标、分支、装备/实体/拓扑条件；将现代可保留的服务端权威、防异常落地、网络校正列为适配层，和旧公式分别验收。
3. 污渍恢复type/level/time三维数据；先准确私有映射20遮罩和UV，再考虑现代64×64/左右手/姿态/盔甲。旧打包错误用明确兼容决策修复。
4. 相机视觉shape、眼部遮挡和FOV分别测，不能通过加实体实心碰撞箱一并解决。
5. 声音按原事件及门控映射；若旧事件就是Vanilla则使用相应现代事件是有证据的迁移，不应换成无关声音后声称原版。

B1已验证的现代高速入池耗散、Y稳定、有条件着陆修复作为回归约束保留。没有在此报告中宣称这些现代回归测试是旧版测试，也没有新增一个候选JAR或继续Task004。
''')
put('07_original_runtime_measurement_plan.md',r'''
# 原版实机测量：状态NOT_RUN与可执行记录规范

本轮是静态文件研究。**没有原版逐tick数据、截图、录像或声音听验，以下全部是待测计划。**没有用B2曲线、独立Java算术或伪造空CSV充当原版结果。已下载官方客户端仅为静态UV/相机参考；未启动1.7.10 Forge、未搭好记录器，也未验证原模组加载。

## 基本矩阵

original-runtime-cases.csv有90个NOT_RUN基础案例：3材料×5场景（静止、水平输入、连续跳跃、高处入沙、深层脱困）×2池深（1、3格）×3种子标签（0、1、2）。这些种子是计划输入，不是已取得的运行种子。泥浆需再扩展窄池/宽池、meta0–3、侧边空气/实体、上覆水/液体，以及无靴/普通靴/WadingBoots；它们当前也未执行，不用90案例掩盖额外缺口。

先记录原模组与Forge/Java版本、所有配置、Jar SHA、维度、原MC/Forge客户端和服务端、实体实际类、玩家皮肤/模型、装备/36格库存、池坐标与metadata、初始worldTime和seed。固定输入与几何、同步RNG初始条件，每场景至少重复三次；仅固定worldSeed并不能证明World RNG消费序列相同。

## 每tick至少记录

- tick ID、worldTime、单调时钟、侧别、玩家UUID/实体类/维度、碰撞回调计数和本tick回调次序。
- posX/Y/Z、prevPosX/Y/Z、AABB.minY脚部位置、AABB.maxY、eyeHeight与eyeWorldY、该回调block坐标/metadata及上邻块。
- k、km、previous k、mtd/getMudDepth/getMudSafe、World RNG调用序号（可安全取得时），而非只记“浸没百分比”。
- motionX/Y/Z在实体更新前、方块回调前后、引擎移动/重力/web后的值；实际ΔX/Y/Z另列，不混为“速度”。
- mr局部、PotionStuck.Level在碰撞和LivingUpdate前后、移动属性modifier UUID/amount/operation、jumpMovementFactor；onGround、isInWeb、collidedHorizontally、fallDistance。
- movement/jump/splash/rotation判定、本地按键、boots/装备/负重配置；自定义air/nativeAir、健康、伤害请求和实际伤害。
- 污渍type/level/time/raw packed值、湿润、遮罩族/等级、overlay触发、第一/第三人称与视角切换、相机最终位置、播放音效/音高/音量和实际泡泡生成。

插桩应采用外部测试Mod/调试代理并保留原JAR哈希，明确记录注入位置；不修改原始上传JAR。不在随机分支内额外消费RNG，不因日志读取改变模拟时钟或运动输入；记录性能与异常，不声称插桩天然无扰动。

## 数据处理与判定

以真实脚部位置和当前材料表面分别定义深度；旧k仍单独保留。按0.25格深度区间输出静止/移动/跳跃各自净下降ΔfootY/Δtick的样本数、分位数/范围，分开客户端和服务端采样、web/ground/装备/元数据与回调次数。停在底部的0速度不能混入悬浮净速度估计；网络批量位移不能当单客户端tick速度。

同时保存视频/关键帧，对照深陷横移/跳跃因子、逐级污染身体部位、干燥残留/湿洗、头埋与仅相机入沙、音效门控。原版事实和现代适配容差等测完再决策，不预先写“越深严格越慢”或给现代速度系数。

运行状态文件original-runtime-status.json明确标为NOT_RUN，所有数据文件列表为空。类/方法和语义未闭合的区域，继续保留UNKNOWN/PARTIAL，不把空数据当通过。
''')
cases=[]
for material in ['Quicksand','SoftQuicksand','Mud']:
 for scenario in ['still','horizontal_move','hold_jump','high_entry','deep_escape']:
  for depth in [1,3]:
   for seed in [0,1,2]:cases.append({'case_id':f'{material}_{scenario}_d{depth}_seed{seed}','material':material,'scenario':scenario,'pool_depth':depth,'planned_seed':seed,'status':'NOT_RUN','data_file':'','recording_file':''})
with (r/'indexes/original-runtime-cases.csv').open('w',newline='')as f:
 writer=csv.DictWriter(f,fieldnames=cases[0]);writer.writeheader();writer.writerows(cases)
(r/'indexes/original-runtime-status.json').write_text(json.dumps({'status':'NOT_RUN','game':'Minecraft 1.7.10 + original MFQM 1.1.1','reason':'This delivery is static evidence analysis; Forge1.7.10 runtime, recorder and actual game measurements were not established or executed. Official client download was used for static external references only.','trajectory_files':[],'recordings':[],'screenshots':[],'measurement_tolerance_decided':False},ensure_ascii=False,indent=2)+'\n')
# Additional exact coordinate evidence acquired later.
yz=(w/'external-decompiled/yz.java').read_text().splitlines();srg=(w/'joined.srg').read_text().splitlines()
p=r/'evidence/external/vanilla-player-coordinates.txt';p.write_text('\n'.join(f'{i}: {yz[i-1]}'for lo,hi in [(120,130),(638,648)]for i in range(lo,hi+1))+'\n\n'+ '\n'.join(l for l in srg if l.startswith(('CL: yz ','FD: sa/L ','MD: yz/g ()F')))+'\n')
# report and machine indexes each explicitly separate evidence level from runtime claims.
(r/'README.zh-CN.md').write_text('''# MFQM原版机制研究第一阶段交付

本轮重新核对原始1.1.1 JAR，**未修改模组代码、未制作新候选、未启动1.7.10游戏**。重点是三核心运动分支、阻碍、分级污渍和相机/声音证据；没有把静态结论或B2测试冒充旧版实测。

- [总报告](COMPLETION_REPORT.zh-CN.md)
- [范围/来源/等级](reports/01_scope_and_evidence.md)
- [39条三核心主要运动分支](reports/02_core_motion_branches.md)
- [坐标、Stuck及tick顺序](reports/03_stuck_and_tick_order.md)
- [污渍类型/等级/UV/清洗](reports/04_coating_state_uv.md)
- [相机/氧气/声音/原图](reports/05_camera_air_audio_resources.md)
- [B2偏差与修复约束](reports/06_port_differences.md)
- [未执行的旧版测量计划](reports/07_original_runtime_measurement_plan.md)

索引：161类、1955方法、29276调用位置、14169跳转位置；methods-with-instructions.json保留方法描述符和完整指令。所有类的方法结构已列出，但**不是1955方法完整语义恢复**。UNKNOWN/PARTIAL明确保留。

输入/工具/哈希见manifest.json、evidence/external/provenance.json。ZIP只含文本、JSON/CSV和研究脚本；原JAR、PNG/OGG、官方客户端二进制都不在交付包里。可以在私有环境按原JAR复核资源名和像素统计，不把报告里的UV统计当新贴图。
''')
print('Reports and 90 NOT_RUN cases written.')
