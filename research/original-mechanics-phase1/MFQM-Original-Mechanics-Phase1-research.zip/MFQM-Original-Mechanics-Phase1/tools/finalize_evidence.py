from pathlib import Path
from zipfile import ZipFile
from PIL import Image
from io import BytesIO
import json,csv,re,hashlib,shutil
r=Path('/workspace/outputs/MFQM-Original-Mechanics-Phase1');w=Path('/workspace/work/mfqm-original-phase1');base=Path('/workspace/work/mfqm-task0035-b2');old=base/'research/task-001/evidence'
(r/'evidence/external').mkdir(exist_ok=True)
# Small textual extracts only; no upstream client, SRG zip, original images/audio are redistributed.
def snippet(path,segments):
 lines=path.read_text().splitlines();return '\n\n'.join(f'FILE {path.name}, decompiler lines {lo}-{hi}\n'+'\n'.join(f'{i}: {lines[i-1]}'for i in range(lo,min(hi,len(lines))+1))for lo,hi in segments)+'\n'
ex=w/'external-decompiled';modern=w/'external-decompiled-modern'
text=snippet(ex/'bhm.java',[(28,79)])+snippet(ex/'bop.java',[(38,70)])+snippet(ex/'blt.java',[(404,471)])+snippet(ex/'ahb.java',[(639,665)])+snippet(ex/'aji.java',[(603,609),(699,710)])
(r/'evidence/external/vanilla-1.7.10-model-camera.txt').write_text(text)
(r/'evidence/external/modern-camera-visual-shape.txt').write_text(snippet(modern/'net/minecraft/client/Camera.java',[(103,116)])+snippet(modern/'net/minecraft/world/level/block/state/BlockBehaviour.java',[(338,343)]))
srg=(w/'joined.srg').read_text().splitlines();wanted=['CL: bhm ','CL: bix ','CL: bop ','CL: blt ','CL: ahb ','CL: aji ','FD: bhm/c ','FD: bhm/d ','FD: bhm/e ','FD: bhm/f ','FD: bhm/g ','FD: bhm/h ','FD: bhm/i ','FD: bop/f ','FD: bop/g ','FD: bop/h ','MD: blt/h (F)V','MD: ahb/a (Lazw;Lazw;)','MD: ahb/a (Lazw;Lazw;ZZZ)','MD: aji/a (IZ)','MD: aji/a (Lahb;IIILazw;Lazw;)']
(r/'evidence/external/srg-relevant-lines.txt').write_text('\n'.join(l for l in srg if any(l.startswith(v)for v in wanted))+'\n')
(r/'evidence/external/provenance.json').write_bytes((w/'external-inputs.json').read_bytes())
# Exact comparison against an independent CFR run, preserving the distinction from semantic review.
comp=[]
for name in ['BlockQuicksand','BlockSoftQuicksand','BlockMud','MFQM','CustomVarPlayer','MuddyEvent','CustomPotionEvent','PotionStuck','AirEvent','CustomRenderOverlayEvent','CustomRenderPlayerEvent','MudModelRenderer','EntityRope']:
 p=next((w/'private-decompiled').rglob(name+'.java'));prior=re.sub(r'^\d+: ?', '',(old/(name+'.analysis.txt')).read_text(),flags=re.M).strip();fresh=p.read_text().strip()
 comp.append({'class':name,'fresh_cfr_sha256':hashlib.sha256(fresh.encode()).hexdigest(),'task001_normalized_sha256':hashlib.sha256(prior.encode()).hexdigest(),'exact_text_equal':fresh==prior,'semantic_proof':'Matching decompilation is corroboration, not runtime verification'})
with (r/'indexes/independent-cfr-comparison.csv').open('w',newline='')as f:
 writer=csv.DictWriter(f,fieldnames=comp[0]);writer.writeheader();writer.writerows(comp)
assert all(x['exact_text_equal']for x in comp)
# UV names now corroborated by official vanilla client ModelBiped + SRG mapping.
u=list(csv.DictReader((r/'indexes/coating-uv-coverage.csv').open()));names={'u0_16_v16_32':'both legs (mirrored shared UV)','u16_40_v16_32':'torso','u40_56_v16_32':'both arms (mirrored shared UV)','u0_32_v0_16':'head','u32_64_v0_16':'headwear/hat outer shell'}
for row in u:row['legacy_standard_biped_part']=names[row['uv_region']];row['scope']='VERIFIED standard vanilla1.7.10 UV region only; not modern64x64/Alex or custom armor mapping'
with (r/'indexes/coating-uv-body-map.csv').open('w',newline='')as f:
 writer=csv.DictWriter(f,fieldnames=u[0]);writer.writeheader();writer.writerows(u)
with ZipFile('/workspace/attachments/14c76068-dd32-4531-8c0d-237671be9f82/[更多流沙] MoreFunQuicksandMod-1.1.1-1.7.10.jar')as z:
 rows=[]
 for label,files in [('Quicksand',['quicksand']),('SoftQuicksand',['SoftQuicksand1','SoftQuicksand0','SoftQuicksand2']),('Mud',['mud'])]:
  for meta,name in enumerate(files):
   path=f'assets/morefunquicksandmod/textures/blocks/{name}.png';im=Image.open(BytesIO(z.read(path))).convert('RGBA')
   rows.append({'material':label,'meta_for_default_icon':meta,'original_resource':path,'width':im.width,'height':im.height,'alpha_extrema':str(im.getchannel('A').getextrema()),'b2_resource':'minecraft:block/sand'if label=='Quicksand'else'minecraft:block/red_sand'if label=='SoftQuicksand'else'minecraft:block/mud','status':'original reference identified; B2 placeholder is a different asset; no assets copied'})
 with (r/'indexes/core-texture-map.csv').open('w',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
for n in ['build_evidence.py','curate_core.py','ArithmeticProbe.java','finalize_evidence.py']:shutil.copy2(w/'tools'/n,r/'tools'/n)
manifest=json.loads((r/'manifest.json').read_text());manifest['sha256_after']=hashlib.sha256(Path('/workspace/attachments/14c76068-dd32-4531-8c0d-237671be9f82/[更多流沙] MoreFunQuicksandMod-1.1.1-1.7.10.jar').read_bytes()).hexdigest();manifest['independent_cfr_checked_classes']=len(comp);manifest['cfr_java_files']=len(list((w/'private-decompiled').rglob('*.java')));manifest['curated_motion_major_decisions']=39
assert manifest['sha256_before']==manifest['sha256_after'];(r/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Independent core CFR comparisons 13/13 equal; original JAR unchanged; UV reference chain recorded.')
