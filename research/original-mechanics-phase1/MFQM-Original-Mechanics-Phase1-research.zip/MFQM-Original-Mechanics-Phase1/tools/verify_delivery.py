#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib,argparse
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--jar',type=Path);a=p.parse_args();r=a.root
m=json.loads((r/'manifest.json').read_text());assert m['class_count']==161 and m['method_count']==1955
classes=list(csv.DictReader((r/'indexes/classes.csv').open()));methods=list(csv.DictReader((r/'indexes/methods.csv').open()));raw=json.loads((r/'indexes/methods-with-instructions.json').read_text())
assert len(classes)==161 and len({x['class']for x in classes})==161
assert len(methods)==len(raw)==1955 and len({x['id']for x in raw})==1955
assert all(x['descriptor'].startswith('(') for x in raw)
assert len(list((r/'evidence/bytecode').glob('*.txt')))==161
by={(x['class'],x['name'],x['descriptor']):x for x in raw}
decisions=list(csv.DictReader((r/'indexes/core-motion-decisions.csv').open()));assert len(decisions)==39
for d in decisions:
 method=by[(d['class'],d['method'],d['descriptor'])];lo,hi=map(int,d['bytecode_offset_region_inclusive'].split('-'));assert 0<=lo<=hi<=method['instructions'][-1]['offset'];assert any(lo<=i['offset']<=hi for i in method['instructions'])
assert len(list(csv.DictReader((r/'indexes/coating-type-map.csv').open())))==33
masks=list(csv.DictReader((r/'indexes/coating-masks.csv').open()));assert len(masks)==20 and all(x['width']=='64'and x['height']=='32'for x in masks)
for x in csv.DictReader((r/'indexes/coating-level-deltas.csv').open()):assert int(x['removed_nonzero'])==0 and int(x['alpha_decreased_pixels'])==0
assert all(x['exact_text_equal']=='True'for x in csv.DictReader((r/'indexes/independent-cfr-comparison.csv').open()))
cases=list(csv.DictReader((r/'indexes/original-runtime-cases.csv').open()));assert len(cases)==90 and all(x['status']=='NOT_RUN' and not x['data_file']for x in cases)
status=json.loads((r/'indexes/original-runtime-status.json').read_text());assert status['status']=='NOT_RUN'and not status['trajectory_files'] and not status['recordings']
assert 'PASS: 10 arithmetic checks only' in (r/'logs/arithmetic-probe.log').read_text()
assert m['sha256_before']==m['sha256_after']
if a.jar:assert hashlib.sha256(a.jar.read_bytes()).hexdigest()==m['sha256_after']
assert not any(p.suffix.lower()in ['.png','.ogg','.jar','.class']for p in r.rglob('*')if p.is_file())
assert (r/'COMPLETION_REPORT.zh-CN.md').exists()
print('PASS: 161 classes / 1955 descriptors / 161 bytecode appendices; 39 curated decisions reference valid method offsets.')
print('PASS: 33 coating types / 20 masks / monotone alpha expansion / 13 independent CFR comparisons.')
print('PASS: 10 offline Java arithmetic checks; 90 original runtime cases explicitly NOT_RUN, no fabricated traces.')
print('PASS: original JAR SHA-256 unchanged; delivery has no PNG/OGG/JAR/class binaries.')
